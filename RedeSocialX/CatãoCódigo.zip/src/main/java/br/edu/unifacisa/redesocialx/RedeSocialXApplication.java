package br.edu.unifacisa.redesocialx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedeSocialXApplication {

	public static void main(String[] args) {
		SpringApplication.run(RedeSocialXApplication.class, args);
	}

}
