package br.edu.unifacisa.redesocialx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedeSocialXApplicationTests {

	@Test
	void contextLoads() {
	}

}
